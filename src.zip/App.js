import React, { useRef, useState, useMemo } from "react";
import "./App.css";
// import Counter from "./component/counter";
// import Input from "./component/input";
// import MultiInput from "./component/multiInput";
// import UserList from "./component/userlist";
import CreateUser from "./component/createuser";
import UserList2 from "./component/userlis2";

function countActiveUser(users) {
  return users.filter((user) => user.active).length; // user 배열 요소 중에 active 된것
}

function App() {
  const [inputs, setinputs] = useState({
    username: "",
    email: "",
  });

  const { username, email } = inputs;
  const onChange = (e) => {
    const { name, value } = e.target;
    setinputs({
      ...inputs,
      [name]: value, // 네임이냐 이메일이냐 찾아서 value 값에 넣어줌
    });
  };

  const nextId = useRef(6); //추가 최초의 배열요소 인덱스값 설정

  const onCreate = () => {
    const user = {
      // 배열요소 객체형식선언
      id: nextId.current,
      username,
      email,
    };

    setUsers(users.concat(user)); // uses배열에 concat메소드 추가된 배열 재 형성

    setinputs({ username: "", email: "" }); //input 공백으로 초기화

    nextId.current += 1; //다음에 추가될 배열요소 인덱스 값
  };

  // 배열을 상태값으로 만들었다
  const [users, setUsers] = useState([
    {
      id: 1,
      username: "김사과",
      email: "apple@apple.com",
    },
    {
      id: 2,
      username: "오렌지",
      email: "orange@orange.com",
    },
    {
      id: 3,
      username: "반하나",
      email: "banana@banana.com",
    },
    {
      id: 4,
      username: "멜롱멜롱",
      email: "melon@melon.com",
    },
    {
      id: 5,
      username: "류승환",
      email: "ryu@ryu.com",
    },
  ]);

  const onRemove = (id) => {
    setUsers(users.filter((user) => user.id !== id));
    // user.id 가 파라미터로 일치하지 않는 원소만 추출해서 새로운 배열을 만듬
    // user.id 가 id 인것을 제거함
  };

  const onToggle = (id) => {
    setUsers(
      users.map((user) =>
        user.id === id ? { ...user, active: !user.active } : user
      )
    );
  };

  const count = useMemo(() => countActiveUser(users), [users]);
  return (
    <div>
      {/* 
      <Counter />
      <Input />
      <MultiInput />
      <UserList />
      */}
      <CreateUser
        onChange={onChange}
        onCreate={onCreate}
        username={username}
        email={email}
      />
      <UserList2 users={users} onRemove={onRemove} onToggle={onToggle} />
      <div>선택된 사용자 수 : {count}</div>
    </div>
  );
}

export default App;
