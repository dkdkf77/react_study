import React from "react";

function User({ user }) {
  // props
  return (
    <div>
      <b>{user.username}</b>
      <span>{user.email}</span>
    </div>
  );
}

function UserList() {
  const users = [
    {
      id: 1,
      username: "김사과",
      email: "apple@apple.com",
    },
    {
      id: 2,
      username: "오렌지",
      email: "orange@orange.com",
    },
    {
      id: 3,
      username: "반하나",
      email: "banana@banana.com",
    },
    {
      id: 4,
      username: "멜롱멜롱",
      email: "melon@melon.com",
    },
    {
      id: 5,
      username: "류승환",
      email: "ryu@ryu.com",
    },
  ];
  return (
    <div>
      {/* <User user={users[0]} />
      <User user={users[1]} />
      <User user={users[2]} />
      <User user={users[3]} />
      <User user={users[4]} /> */}
      {/* map()함수는 배열요소 갯수만큼 반복실행  ()=>{} => ()=>() 화면에 렌더링*/}
      {users.map((user, index /*(user 배열요소, index 인덱스 값)*/) => (
        <User user={user} key={index} />
      ))}
    </div>
  );
}

export default UserList;
