import React from "react";
import { useRef } from "react";
import { useState } from "react";

function MultiInput() {
  const [inputs, setInputs] = useState({
    // 초기값설정(객체로 선언)
    userid: "",
    name: "",
  });
  const useridInput = useRef(); //요소 선택 => 선택자로 사용 ref (해당태그에 ref='useridInput' 요소ㅓ 지정)
  const { userid, name } = inputs; //비 구조화 할당을 통해 값을 전달

  const onChange = (e) => {
    //input 태그에 이벤트 발생
    const { value, name } = e.target; // e targe은 value와 name 값으로 나눈다
    setInputs({ ...inputs, [name]: value }); // ...spread 문법(객체를 복사) 은 하나가 아니라 두개가 온다는 의미 , // name 키를 가진 값을 value로 설정-> 초기 값 지정된 곳에 값 전달
  };
  const onReset = () => {
    setInputs({
      userid: "",
      name: "",
    });
    useridInput.current.focus();
  };

  return (
    <div>
      <input
        name="userid"
        onChange={onChange}
        placeholder="아이디"
        value={userid}
        ref={useridInput}
      />
      <input name="name" onChange={onChange} placeholder="이름" value={name} />
      <button onClick={onReset}>지우기</button>
      <div>
        <b>아이디: {userid}</b>,<b>이름:{name}</b>
      </div>
    </div>
  );
}

export default MultiInput;
