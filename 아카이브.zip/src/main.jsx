import React from "react";

function MainPage(){
    return(
        <div>
            <section className="mainImg">mainImg</section>
            <section className="contents">
                <article className="product1">product1</article>
                <article className="product2">product2</article>
                <article className="product3">product3</article>
                <article className="product4">product4</article>
                <article className="product5">product5</article>
            </section>
        </div>
    )
}

export default MainPage;