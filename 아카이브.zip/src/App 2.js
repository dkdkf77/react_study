
import './App.css';
import Header from './header';

function App() {
  return (
    <div className="wrap">
      <Header />
    </div>
  );
}

export default App;
