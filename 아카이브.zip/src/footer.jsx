import React from "react";

function Footer(){
    return(
        <footer className="footer">
            <div className="fInfo">fInfo</div>
            <div className="fMenu">fMenu</div>
            <div className="fAddress">fAddress</div>
        </footer>
    )
}

export default Footer;