import React from 'react';
import './css/product.css';

function Product() {
  return (
    <div>
      <article>
        <div className="homeBtn">
          <p>HOME 냉장제품</p>
        </div>
        <header className="productHeader">
          <div className="productHeaderIn">
            <h3>냉장제품</h3>
            <div>
              <p>
                총 <span>27개</span>의 상품이 있습니다/
              </p>
              <button>상세검색 +</button>
            </div>
          </div>
        </header>
        <section className="contnets">
          <header className="contentHeader">
            <div></div>
          </header>
          <section className="contentSection">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
          </section>
          <footer className="contentFooter">
            <ul>
              <li>1</li>
              <li>2</li>
            </ul>
          </footer>
        </section>
      </article>
    </div>
  );
}

export default Product;
